
import React from 'react';
import { Button } from '@/components/ui/button';
import { Wallet } from 'lucide-react';

interface HeaderProps {
  user: any;
  onLogout: () => void;
  budget: number;
}

export const Header: React.FC<HeaderProps> = ({ user, onLogout, budget }) => {
  return (
    <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
              <Wallet className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Budget Buddy
              </h1>
              <p className="text-sm text-gray-600">Welcome back, {user.name}!</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {budget > 0 && (
              <div className="hidden sm:block text-right">
                <p className="text-sm text-gray-600">Budget Limit</p>
                <p className="text-lg font-semibold text-green-600">₹{budget.toLocaleString()}</p>
              </div>
            )}
            <Button 
              onClick={onLogout}
              variant="outline"
              className="border-red-300 text-red-600 hover:bg-red-50"
            >
              Logout
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};
