
import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { BudgetOverview } from '@/components/BudgetOverview';
import { TransactionForm } from '@/components/TransactionForm';
import { TransactionList } from '@/components/TransactionList';
import { ExpenseChart } from '@/components/ExpenseChart';
import { BudgetSetter } from '@/components/BudgetSetter';
import { NotificationSystem } from '@/components/NotificationSystem';
import { useToast } from '@/hooks/use-toast';

interface DashboardProps {
  user: any;
  onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const [budget, setBudget] = useState(0);
  const [emergencyLimit, setEmergencyLimit] = useState(200); // Default emergency limit
  const [transactions, setTransactions] = useState([]);
  const [showBudgetSetter, setShowBudgetSetter] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    // Load data from localStorage
    const savedBudget = localStorage.getItem('budgetData');
    const savedEmergencyLimit = localStorage.getItem('emergencyLimit');
    const savedTransactions = localStorage.getItem('transactions');
    
    if (savedBudget) {
      setBudget(JSON.parse(savedBudget));
    } else {
      setShowBudgetSetter(true);
    }

    if (savedEmergencyLimit) {
      setEmergencyLimit(JSON.parse(savedEmergencyLimit));
    }
    
    if (savedTransactions) {
      setTransactions(JSON.parse(savedTransactions));
    }
  }, []);

  useEffect(() => {
    // Save data to localStorage
    localStorage.setItem('budgetData', JSON.stringify(budget));
    localStorage.setItem('emergencyLimit', JSON.stringify(emergencyLimit));
    localStorage.setItem('transactions', JSON.stringify(transactions));
    
    // Check for budget overruns
    checkBudgetLimits();
  }, [budget, emergencyLimit, transactions]);

  const checkBudgetLimits = () => {
    const totalExpenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    
    if (budget > 0 && totalExpenses > budget) {
      const overrun = totalExpenses - budget;
      const newNotification = {
        id: Date.now(),
        type: 'error',
        title: 'Budget Exceeded!',
        message: `You've exceeded your budget by ₹${overrun.toFixed(2)}`,
        timestamp: new Date().toISOString(),
      };
      
      setNotifications(prev => [newNotification, ...prev.slice(0, 4)]);
      
      toast({
        title: "Budget Alert",
        description: `You've exceeded your budget by ₹${overrun.toFixed(2)}`,
        variant: "destructive",
      });
    }
  };

  const handleBudgetSet = (newBudget: number, newEmergencyLimit?: number) => {
    setBudget(newBudget);
    if (newEmergencyLimit !== undefined) {
      setEmergencyLimit(newEmergencyLimit);
    }
    setShowBudgetSetter(false);
    toast({
      title: "Budget Set",
      description: `Your budget of ₹${newBudget} has been saved successfully.`,
    });
  };

  const handleAddTransaction = (transaction: any) => {
    const newTransaction = {
      ...transaction,
      id: Date.now(),
      timestamp: new Date().toISOString(),
    };
    setTransactions(prev => [newTransaction, ...prev]);
    
    toast({
      title: "Transaction Added",
      description: `${transaction.type === 'income' ? 'Income' : 'Expense'} of ₹${transaction.amount} added successfully.${transaction.isEmergency ? ' (Emergency)' : ''}`,
    });
  };

  const usedEmergencyAmount = transactions
    .filter(t => t.type === 'expense' && t.emergencyAmount)
    .reduce((sum, t) => sum + (t.emergencyAmount || 0), 0);

  if (showBudgetSetter) {
    return (
      <div className="min-h-screen">
        <Header user={user} onLogout={onLogout} budget={budget} />
        <BudgetSetter onBudgetSet={handleBudgetSet} />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header user={user} onLogout={onLogout} budget={budget} />
      <NotificationSystem notifications={notifications} />
      
      <div className="container mx-auto px-4 py-6 space-y-6">
        <BudgetOverview 
          budget={budget} 
          transactions={transactions} 
          onEditBudget={() => setShowBudgetSetter(true)}
          emergencyLimit={emergencyLimit}
          usedEmergencyAmount={usedEmergencyAmount}
        />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-6">
            <TransactionForm 
              onAddTransaction={handleAddTransaction}
              budget={budget}
              transactions={transactions}
              emergencyLimit={emergencyLimit}
              usedEmergencyAmount={usedEmergencyAmount}
            />
            <ExpenseChart transactions={transactions} />
          </div>
          
          <div>
            <TransactionList transactions={transactions} />
          </div>
        </div>
      </div>
    </div>
  );
};
