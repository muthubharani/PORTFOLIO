
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface TransactionFormProps {
  onAddTransaction: (transaction: any) => void;
  budget: number;
  transactions: any[];
  emergencyLimit: number;
  usedEmergencyAmount: number;
}

export const TransactionForm: React.FC<TransactionFormProps> = ({ 
  onAddTransaction, 
  budget, 
  transactions, 
  emergencyLimit, 
  usedEmergencyAmount 
}) => {
  const [type, setType] = useState('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [isEmergency, setIsEmergency] = useState(false);

  const expenseCategories = [
    'Food & Dining', 'Transportation', 'Shopping', 'Entertainment',
    'Bills & Utilities', 'Healthcare', 'Education', 'Travel', 'Other'
  ];

  const incomeCategories = [
    'Salary', 'Freelance', 'Business', 'Investment', 'Gift', 'Other'
  ];

  const totalExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const remainingBudget = budget - totalExpenses;
  const remainingEmergency = emergencyLimit - usedEmergencyAmount;
  const budgetExceeded = remainingBudget < 0;

  const getBudgetWarning = () => {
    if (type !== 'expense' || !amount) return null;
    
    const expenseAmount = parseFloat(amount);
    
    if (!budgetExceeded && remainingBudget >= expenseAmount) {
      return null; // Within budget
    }
    
    if (budgetExceeded || remainingBudget < expenseAmount) {
      const overAmount = budgetExceeded ? expenseAmount : expenseAmount - remainingBudget;
      
      if (remainingEmergency >= overAmount) {
        return (
          <Alert className="border-yellow-500 bg-yellow-50">
            <AlertDescription className="text-yellow-800">
              🟡 Budget exceeded! You can use only ₹{remainingEmergency} from your emergency allowance.
            </AlertDescription>
          </Alert>
        );
      } else if (remainingEmergency > 0) {
        return (
          <Alert className="border-orange-500 bg-orange-50">
            <AlertDescription className="text-orange-800">
              🟠 Budget exceeded! You can use only ₹{remainingEmergency} from your emergency allowance.
            </AlertDescription>
          </Alert>
        );
      } else {
        return (
          <Alert className="border-red-500 bg-red-50">
            <AlertDescription className="text-red-800">
              🔴 Budget exceeded! No amount left to spend unless it's an emergency.
            </AlertDescription>
          </Alert>
        );
      }
    }
    
    return null;
  };

  const canAddExpense = () => {
    if (type !== 'expense' || !amount) return true;
    
    const expenseAmount = parseFloat(amount);
    
    // Within budget
    if (!budgetExceeded && remainingBudget >= expenseAmount) {
      return true;
    }
    
    // Over budget but marked as emergency
    if (isEmergency) {
      return true;
    }
    
    // Over budget, check emergency allowance
    const overAmount = budgetExceeded ? expenseAmount : expenseAmount - remainingBudget;
    return remainingEmergency >= overAmount;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !category) return;

    const expenseAmount = parseFloat(amount);
    let emergencyUsed = 0;

    if (type === 'expense') {
      const overAmount = budgetExceeded ? expenseAmount : Math.max(0, expenseAmount - remainingBudget);
      
      if (overAmount > 0) {
        emergencyUsed = Math.min(overAmount, isEmergency ? expenseAmount : remainingEmergency);
      }
    }

    onAddTransaction({
      type,
      amount: expenseAmount,
      category,
      description: description || `${type === 'income' ? 'Income' : 'Expense'} - ${category}`,
      isEmergency,
      emergencyAmount: emergencyUsed,
    });

    setAmount('');
    setCategory('');
    setDescription('');
    setIsEmergency(false);
  };

  const categories = type === 'expense' ? expenseCategories : incomeCategories;
  const budgetWarning = getBudgetWarning();
  const showEmergencyOption = type === 'expense' && amount && budgetWarning && remainingEmergency <= 0;

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-800">Add Transaction</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Type</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="income">Income</SelectItem>
                  <SelectItem value="expense">Expense</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Amount (₹)</Label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                min="0.01"
                step="0.01"
              />
            </div>
          </div>

          {budgetWarning && (
            <div className="space-y-2">
              {budgetWarning}
              
              {showEmergencyOption && (
                <div className="flex items-center space-x-2 mt-3">
                  <Checkbox 
                    id="emergency" 
                    checked={isEmergency}
                    onCheckedChange={setIsEmergency}
                  />
                  <Label htmlFor="emergency" className="text-sm font-medium text-red-600">
                    Mark as Emergency Expense
                  </Label>
                </div>
              )}
            </div>
          )}

          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Description (Optional)</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add a note about this transaction..."
              rows={2}
            />
          </div>

          <Button 
            type="submit" 
            className={`w-full ${type === 'income' 
              ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700' 
              : 'bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700'
            } text-white font-medium`}
            disabled={!amount || !category || (type === 'expense' && !canAddExpense())}
          >
            Add {type === 'income' ? 'Income' : 'Expense'}
            {isEmergency && type === 'expense' && ' (Emergency)'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};
