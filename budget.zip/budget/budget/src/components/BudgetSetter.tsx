
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

interface BudgetSetterProps {
  onBudgetSet: (budget: number) => void;
}

export const BudgetSetter: React.FC<BudgetSetterProps> = ({ onBudgetSet }) => {
  const [budgetAmount, setBudgetAmount] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(budgetAmount);
    if (amount > 0) {
      onBudgetSet(amount);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-800">Set Your Budget</CardTitle>
          <CardDescription>
            Set your monthly budget limit to start tracking your expenses
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="budget">Monthly Budget (₹)</Label>
              <Input
                id="budget"
                type="number"
                value={budgetAmount}
                onChange={(e) => setBudgetAmount(e.target.value)}
                placeholder="Enter your budget limit"
                className="text-lg text-center font-semibold"
                min="1"
                step="0.01"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white font-medium py-2.5"
              disabled={!budgetAmount || parseFloat(budgetAmount) <= 0}
            >
              Set Budget
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
