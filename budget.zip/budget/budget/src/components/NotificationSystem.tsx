
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface Notification {
  id: number;
  type: 'error' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: string;
}

interface NotificationSystemProps {
  notifications: Notification[];
}

export const NotificationSystem: React.FC<NotificationSystemProps> = ({ notifications }) => {
  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-50 space-y-2 max-w-sm">
      {notifications.slice(0, 3).map((notification) => (
        <Alert 
          key={notification.id}
          className={`shadow-lg border-l-4 ${
            notification.type === 'error' 
              ? 'border-l-red-500 bg-red-50' 
              : notification.type === 'warning'
              ? 'border-l-yellow-500 bg-yellow-50'
              : 'border-l-blue-500 bg-blue-50'
          } animate-fade-in`}
        >
          <AlertTitle className={
            notification.type === 'error' 
              ? 'text-red-800' 
              : notification.type === 'warning'
              ? 'text-yellow-800'
              : 'text-blue-800'
          }>
            {notification.title}
          </AlertTitle>
          <AlertDescription className={
            notification.type === 'error' 
              ? 'text-red-600' 
              : notification.type === 'warning'
              ? 'text-yellow-600'
              : 'text-blue-600'
          }>
            {notification.message}
          </AlertDescription>
        </Alert>
      ))}
    </div>
  );
};
