
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

interface BudgetOverviewProps {
  budget: number;
  transactions: any[];
  onEditBudget: () => void;
  emergencyLimit: number;
  usedEmergencyAmount: number;
}

export const BudgetOverview: React.FC<BudgetOverviewProps> = ({ 
  budget, 
  transactions, 
  onEditBudget,
  emergencyLimit,
  usedEmergencyAmount
}) => {
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const totalExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const remaining = budget - totalExpenses;
  const budgetUsagePercentage = budget > 0 ? (totalExpenses / budget) * 100 : 0;
  const emergencyUsagePercentage = emergencyLimit > 0 ? (usedEmergencyAmount / emergencyLimit) * 100 : 0;
  
  const getBudgetStatus = () => {
    if (budgetUsagePercentage <= 70) return { color: 'text-green-600', bg: 'bg-green-500' };
    if (budgetUsagePercentage <= 90) return { color: 'text-yellow-600', bg: 'bg-yellow-500' };
    return { color: 'text-red-600', bg: 'bg-red-500' };
  };

  const status = getBudgetStatus();

  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
      <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Total Budget</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold">₹{budget.toLocaleString()}</div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onEditBudget}
              className="text-white hover:bg-white/20"
            >
              Edit
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Total Income</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{totalIncome.toLocaleString()}</div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{totalExpenses.toLocaleString()}</div>
        </CardContent>
      </Card>

      <Card className={`bg-gradient-to-r ${remaining >= 0 ? 'from-green-500 to-green-600' : 'from-red-500 to-red-600'} text-white`}>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">
            {remaining >= 0 ? 'Remaining' : 'Over Budget'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{Math.abs(remaining).toLocaleString()}</div>
          <div className="mt-2">
            <Progress 
              value={Math.min(budgetUsagePercentage, 100)} 
              className="h-2" 
            />
            <p className="text-xs mt-1 opacity-90">
              {budgetUsagePercentage.toFixed(1)}% of budget used
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Emergency Fund</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-lg font-bold">₹{(emergencyLimit - usedEmergencyAmount).toLocaleString()}</div>
          <div className="text-xs opacity-90">of ₹{emergencyLimit.toLocaleString()}</div>
          <div className="mt-2">
            <Progress 
              value={emergencyUsagePercentage} 
              className="h-2" 
            />
            <p className="text-xs mt-1 opacity-90">
              {emergencyUsagePercentage.toFixed(1)}% used
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
